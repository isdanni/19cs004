SOCKS5 Proxy Package for Go
===========================

Documentation: <http://godoc.org/github.com/btcsuite/go-socks/socks>

License
-------

3-clause BSD. See LICENSE file.
