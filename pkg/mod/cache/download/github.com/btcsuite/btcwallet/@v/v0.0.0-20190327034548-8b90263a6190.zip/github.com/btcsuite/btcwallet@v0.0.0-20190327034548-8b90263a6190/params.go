// Copyright (c) 2013-2015 The btcsuite developers
// Use of this source code is governed by an ISC
// license that can be found in the LICENSE file.

package main

import "github.com/btcsuite/btcwallet/netparams"

var activeNet = &netparams.MainNetParams
