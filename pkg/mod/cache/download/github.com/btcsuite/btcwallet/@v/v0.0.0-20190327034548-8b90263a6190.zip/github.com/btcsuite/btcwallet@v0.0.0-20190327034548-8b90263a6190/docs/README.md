### Guides

[Rebuilding all transaction history with forced rescans](https://github.com/btcsuite/btcwallet/tree/master/docs/force_rescans.md)
