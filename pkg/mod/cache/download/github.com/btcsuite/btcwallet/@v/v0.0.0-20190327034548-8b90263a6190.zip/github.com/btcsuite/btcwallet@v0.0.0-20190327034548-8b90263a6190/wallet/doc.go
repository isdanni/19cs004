// Copyright (c) 2015 The btcsuite developers
// Use of this source code is governed by an ISC
// license that can be found in the LICENSE file.

/*
Package wallet provides ...
TODO: Flesh out this section

Overview

*/
package wallet
