# The macaroon bakery

This repository is a companion to http://github.com/go-macaroon .
It holds higher level operations for building systems with macaroons.

For documentation, see:

- http://godoc.org/gopkg.in/macaroon-bakery.v2/bakery
- http://godoc.org/gopkg.in/macaroon-bakery.v2/httpbakery
- http://godoc.org/gopkg.in/macaroon-bakery.v2/bakery/checkers
