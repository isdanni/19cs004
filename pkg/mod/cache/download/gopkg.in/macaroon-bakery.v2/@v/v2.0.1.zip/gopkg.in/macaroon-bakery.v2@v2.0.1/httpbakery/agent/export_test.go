package agent

var AddCookie = addCookie
